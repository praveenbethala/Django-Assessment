from django.core.management.base import BaseCommand
from django.db import transaction
from django.db.models import F
from django.utils.timezone import now

from app.models import Event, Aggregate, AggregationCheckpoint


class Command(BaseCommand):
    help = "Aggregate events into minute buckets"

    def handle(self, *args, **options):
        checkpoint, _ = AggregationCheckpoint.objects.get_or_create(
            id=1,
            defaults={"last_processed_at": now()},
        )

        events = Event.objects.filter(
            timestamp__gt=checkpoint.last_processed_at
        ).order_by("timestamp")

        for event in events:
            bucket_start = event.timestamp.replace(second=0, microsecond=0)

            with transaction.atomic():
                agg, created = Aggregate.objects.get_or_create(
                    tenant_id=event.tenant_id,
                    bucket_start=bucket_start,
                    bucket_size="minute",
                    source=event.source,
                    event_type=event.event_type,
                    defaults={
                        "count": 1,
                        "first_seen": event.timestamp,
                        "last_seen": event.timestamp,
                    },
                )

                if not created:
                    agg.count = F("count") + 1
                    agg.last_seen = event.timestamp
                    agg.save()

            checkpoint.last_processed_at = event.timestamp
            checkpoint.save(update_fields=["last_processed_at"])
