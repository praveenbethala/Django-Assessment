from django.db import connection
from django.db.models import Sum
from django.utils.dateparse import parse_datetime
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status

from .models import Event, Aggregate
from .serializers import EventSerializer
from .services import ingest_event, bulk_ingest_events


@api_view(["POST"])
def post_event(request):
    serializer = EventSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)
    ingest_event(serializer.validated_data)
    return Response({"message": "Event accepted"}, status=201)


@api_view(["POST"])
def post_events_bulk(request):
    if not isinstance(request.data, list):
        return Response({"error": "List expected"}, status=400)

    if len(request.data) > 5000:
        return Response({"error": "Payload too large"}, status=413)

    serializer = EventSerializer(data=request.data, many=True)
    serializer.is_valid(raise_exception=True)
    bulk_ingest_events(serializer.validated_data)
    return Response({"message": "Bulk events accepted"}, status=201)


@api_view(["GET"])
def list_events(request):
    tenant_id = request.query_params.get("tenant_id")
    if not tenant_id:
        return Response({"error": "tenant_id required"}, status=400)

    qs = Event.objects.filter(tenant_id=tenant_id)

    if source := request.query_params.get("source"):
        qs = qs.filter(source=source)
    if event_type := request.query_params.get("event_type"):
        qs = qs.filter(event_type=event_type)
    if from_ts := request.query_params.get("from"):
        qs = qs.filter(timestamp__gte=parse_datetime(from_ts))
    if to_ts := request.query_params.get("to"):
        qs = qs.filter(timestamp__lte=parse_datetime(to_ts))

    limit = int(request.query_params.get("limit", 100))
    offset = int(request.query_params.get("offset", 0))

    qs = qs.order_by("timestamp", "event_id")[offset: offset + limit]
    return Response(EventSerializer(qs, many=True).data)


@api_view(["GET"])
def metrics(request):
    tenant_id = request.query_params.get("tenant_id")
    if not tenant_id:
        return Response({"error": "tenant_id required"}, status=400)

    bucket_size = request.query_params.get("bucket_size", "minute")
    qs = Aggregate.objects.filter(
        tenant_id=tenant_id,
        bucket_size=bucket_size,
    )

    if source := request.query_params.get("source"):
        qs = qs.filter(source=source)
    if event_type := request.query_params.get("event_type"):
        qs = qs.filter(event_type=event_type)

    data = (
        qs.values("bucket_start", "source", "event_type")
        .annotate(count=Sum("count"))
        .order_by("bucket_start")
    )
    return Response(list(data))


@api_view(["GET"])
def health(request):
    return Response({"status": "ok"})


@api_view(["GET"])
def ready(request):
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
        return Response({"status": "ready"})
    except Exception:
        return Response({"status": "not ready"}, status=503)
