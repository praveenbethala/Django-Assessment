from django.urls import path
from .views import (
    post_event,
    post_events_bulk,
    list_events,
    metrics,
    health,
    ready,
)

urlpatterns = [
    path("app", post_event),
    path("app/bulk", post_events_bulk),
    path("app/list", list_events),
    path("metrics", metrics),
    path("health", health),
    path("ready", ready),
]
