from django.db import transaction, IntegrityError
from .models import Event


def ingest_event(data: dict) -> None:
    try:
        with transaction.atomic():
            Event.objects.create(**data)
    except IntegrityError:
        pass


def bulk_ingest_events(events: list[dict]) -> int:
    objs = [Event(**e) for e in events]
    Event.objects.bulk_create(
        objs,
        ignore_conflicts=True,
        batch_size=1000,
    )
    return len(objs)
