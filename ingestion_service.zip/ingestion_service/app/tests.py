import pytest
from app.models import Event, Aggregate


@pytest.mark.django_db
def test_idempotent_ingest(client):
    event = {
        "event_id": "e1",
        "tenant_id": "t1",
        "source": "web",
        "event_type": "click",
        "timestamp": "2024-01-01T00:00:00Z",
        "payload": {},
    }

    client.post("/app", event, content_type="application/json")
    client.post("/app", event, content_type="application/json")

    assert Event.objects.count() == 1


@pytest.mark.django_db
def test_bulk_limit(client):
    payload = [{}] * 5001
    res = client.post("/app/bulk", payload, content_type="application/json")
    assert res.status_code == 413


@pytest.mark.django_db
def test_metrics(client):
    Aggregate.objects.create(
        tenant_id="t1",
        bucket_start="2024-01-01T00:00:00Z",
        bucket_size="minute",
        source="web",
        event_type="click",
        count=2,
        first_seen="2024-01-01T00:00:00Z",
        last_seen="2024-01-01T00:00:00Z",
    )

    res = client.get("/metrics?tenant_id=t1")
    assert res.status_code == 200
    assert res.json()[0]["count"] == 2


def test_health_ready(client):
    assert client.get("/health").status_code == 200
    assert client.get("/ready").status_code in (200, 503)
