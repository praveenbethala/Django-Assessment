from django.db import models


class Event(models.Model):
    event_id = models.CharField(max_length=128, primary_key=True)
    tenant_id = models.CharField(max_length=128, db_index=True)
    source = models.CharField(max_length=64, db_index=True)
    event_type = models.CharField(max_length=64, db_index=True)
    timestamp = models.DateTimeField(db_index=True)
    payload = models.JSONField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [
            models.Index(fields=["tenant_id", "timestamp"]),
        ]


class Aggregate(models.Model):
    tenant_id = models.CharField(max_length=128)
    bucket_start = models.DateTimeField(db_index=True)
    bucket_size = models.CharField(max_length=10)  # minute | hour
    source = models.CharField(max_length=64, null=True)
    event_type = models.CharField(max_length=64, null=True)
    count = models.PositiveIntegerField()
    first_seen = models.DateTimeField()
    last_seen = models.DateTimeField()

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=[
                    "tenant_id",
                    "bucket_start",
                    "bucket_size",
                    "source",
                    "event_type",
                ],
                name="uniq_aggregate_bucket",
            )
        ]
