from rest_framework import serializers
from django.utils.timezone import is_aware
from .models import Event


class EventSerializer(serializers.ModelSerializer):
    class Meta:
        model = Event
        fields = "__all__"

    def validate_timestamp(self, value):
        if not is_aware(value):
            raise serializers.ValidationError("Timestamp must be UTC-aware")
        return value
